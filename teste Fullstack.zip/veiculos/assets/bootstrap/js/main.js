$(document).ready(function(){
	$('.card').on('click',function()
	{
		$('.card').each(function()
		{
			$(this).removeClass('cardActive');
		})

		$(this).addClass('cardActive');

		var idNome = $(this).find('a').attr('id');
		
		$('.detalhe').each(function()
		{
			$(this).css('display','none');
		})
		$('#veiculo_'+idNome).fadeIn();
	})


	$("#salvar").on('click', function(){
		var nVeiculo 	= $("#nVeiculo").val();
		var nMarca 		= $("#nMarca").val();
		var nAno 		= $("#nAno").val();
		var nCheck 		= $("#nCheck").is(':checked');
		var nDescricao 	= $("#nDescricao").val();

		if(nCheck == true){
			nCheckSave = 1;
		}else{
			nCheckSave = 0;
		}

		$.ajax({
			url: 'pagesController/cPost',
			type: 'POST',
			data: {
				_nVeiculo: nVeiculo,
				_nMarca: nMarca,
				_nAno: nAno,
				_nCheck: nCheckSave,
				_nDescricao: nDescricao
			},
			success: function(data){
				console.log(data);
				window.location.href = "home";
				 $("#myModal").modal('hide');
			}

		});
	});

	var checkedUpdate;

	$("#nCheckUp").click(function(){
		if($(this).is(':checked')){
			checkedUpdate = 1;
			console.log(checkedUpdate);
		}else{
			checkedUpdate = 0;
			console.log(checkedUpdate);
		}
	});

	$("#salvarUpdate").on('click', function(){
		var nVeiculoUp 		= $("#nVeiculoUp").val();
		var nMarcaUp 		= $("#nMarcaUp").val();
		var nAnoUp 			= $("#nAnoUp").val();
		var nCheckUp 		= $("#nCheckUp").is(':checked');
		var nDescricaoUp 	= $("#nDescricaoUp").val();
		var idVeiculoUp		= $("#idVeiculoUp").val();
		var createdUp		= $("#createdUp").val();
		var ckV = null;

		if(nCheckUp == true){
			ckV = 1;
		}else{
			ckV = 0;
		}

		$.ajax({
			url: 'pagesController/cUpdate',
			type: 'POST',
			data:{
				_idVeiculoUp: idVeiculoUp,
				_nVeiculoUp: nVeiculoUp,
				_nMarcaUp: nMarcaUp,
				_nAnoUp: nAnoUp,
				_nCheckUp: ckV,
				_createdUp: createdUp,
				_nDescricaoUp: nDescricaoUp
			}, 
			success: function(data){
				console.log(data);
				window.location.href = "home";
				 $("#mEdit").modal('hide');
			}
		});

	});


});

function atualiza(valor){    

    $.ajax({
        url: 'pagesController/cGetWhere',
        type: 'POST',
        dataType: 'JSON',
        data: {
            _id: valor
        },
        success: function(resp){
        	var ck = resp.veiculos.vendido;
        	var _ck;


        	switch (ck) {
        		case '1':
        			_ck = '<input type="checkbox" id="nCheckUp" name="nCheckUp" checked="checked"> Vendido';
        			break;
        		case '0':
        			_ck = '<input type="checkbox" id="nCheckUp" name="nCheckUp"> Vendido';
        			break;
        		default:
        			_ck = '<input type="checkbox" id="nCheckUp" name="nCheckUp"> Vendido';
        			break;
        	}

            console.log(resp);
            document.getElementById('idVeiculoUp').value = resp.veiculos.id;
            document.getElementById('nVeiculoUp').value = resp.veiculos.veiculo;
            document.getElementById('nMarcaUp').value = resp.veiculos.marca;
            document.getElementById('nAnoUp').value = resp.veiculos.ano;
            document.getElementById('cks').innerHTML = _ck;
            document.getElementById('nDescricaoUp').value = resp.veiculos.descricao;
            document.getElementById('createdUp').value = resp.veiculos.created;
            


        }
    });
}
/*
function search(q){	

	$.ajax({
		url: 'pagesController/cVeiculosGet',
		type: 'POST',
		//dataType: 'JSON',
		data: {
			_q: q
		},
		success: function(data){
			console.log(data);
			var resp = '<div class="card">';
				resp += '<a href="javascript:void(0);" id="<?= $id; ?>">';
		        resp += '<div class="col-md-10">';
				resp += '<div class="row">';
				resp += '<div class="col-md-12">';
				resp += '<span class="marca"><?= $marca; ?></span>';
				resp += '</div>';
				resp += '<div class="col-md-12">';
				resp += '<span class="veiculo"><?= $carro; ?></span>';
				resp += '</div>';
				resp += '<div class="col-md-12">';
				resp += '<span class="ano"><?= $ano; ?></span>';
				resp += '</div>';  
				resp += '</div>';
				resp += '</div>';
				resp += '<div class="col-md-2">';
				resp += '<?php';
				resp += 'if($vendido == 1){';
				resp += '?>';
				resp += '<i class=" aj-tag-ven glyphicon glyphicon-tag" id="aj-cor-tag"></i>';
				//resp += '<?php }else{?>';

				//resp += '<i class=" aj-tag glyphicon glyphicon-tag" id="aj-cor-tag"></i>';
				resp += '<?php }?>';
				resp += '</div>';
				resp += '</a>';
				resp += '</div>';

				document.getElementById('card').innerHTML = resp;

		}	

	});
}*/