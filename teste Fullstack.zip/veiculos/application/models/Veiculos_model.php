<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Veiculos_model extends CI_Model{

	function __construct(){
		parent::__construct();		
		$this->load->database();
	}	

	public function mVeiculosGet(){			
		$veiculos = $this->db->get('veiculos');
		$response = $veiculos->result_array();		
		return $response;		
	}

	public function mPost(){
		$_nVeiculo 		= $this->input->post("_nVeiculo");
		$_nMarca 		= $this->input->post("_nMarca");
		$_nAno 			= $this->input->post("_nAno");
		$_nCheck 		= $this->input->post("_nCheck");
		$_nDescricao 	= $this->input->post("_nDescricao");

		if( $_nCheck == 1 ){
			$ck = 1;
		}else{
			$ck = 0;
		}

		$veiculos = array(
				'veiculo' 	=> $_nVeiculo,
				'marca' 	=> $_nMarca,
				'ano' 		=> $_nAno,
				'descricao' => $_nDescricao,
				'vendido' 	=> $ck,
				'created' 	=> date('Y-m-d H:i:s'),
				'updated' 	=> '0000-00-00 00:00:00'
			);

		$this->db->insert('veiculos', $veiculos);
	}


	public function mGetWhere(){
		$_id = $this->input->post("_id");	
		
		$veiculos = $this->db->get_where('veiculos', array('id' => $_id));
		$result = $veiculos->result_array();
		foreach($result as $itens){
			$json['veiculos'] = $itens;
		}

		echo json_encode($json);
	}


	public function mSearch(){
		$_q = $this->input->post("_q");
		$this->db->like('veiculo', $_q);
		$veiculos = $this->db->get('veiculos');
		$result = $veiculos->result_array();
		foreach($result as $itens){
			$id = $itens['id'];
			$marca = $itens['marca'];
			$carro = $itens['veiculo'];
			$ano = $itens['ano'];
			$vendido = $itens['vendido'];
			$resp = '<div class="card">
                <a href="javascript:void(0);" id="' . $id . '">
                <div class="col-md-10">
                    <div class="row">
                        <div class="col-md-12">
                            <span class="marca">'.$carro.'</span>
                        </div>  
                        <div class="col-md-12">
                            <span class="veiculo">'.$marca.'</span>
                        </div>  
                        <div class="col-md-12">
                            <span class="ano">'.$ano.'</span>
                        </div>  
                    </div>
                </div>

                <div class="col-md-2">';
                    
                        if($vendido == 1){
                   
                $resp .= '<i class=" aj-tag-ven glyphicon glyphicon-tag" id="aj-cor-tag"></i>';
                }else{

                $resp .= '<i class=" aj-tag glyphicon glyphicon-tag" id="aj-cor-tag"></i>';
                }
                $resp .= '</div>
            </a>
        </div>';
        echo $resp;

		}

		
	}


	public function mUpdate(){
		$_idVeiculoUp 	= $this->input->post("_idVeiculoUp");
		$_nVeiculoUp 	= $this->input->post("_nVeiculoUp");
		$_nMarcaUp 		= $this->input->post("_nMarcaUp");
		$_nAnoUp 		= $this->input->post("_nAnoUp");
		$_nCheckUp 		= $this->input->post("_nCheckUp");
		$_nDescricaoUp 	= $this->input->post("_nDescricaoUp");
		$_createdUp 	= $this->input->post("_createdUp");

		$veiculosUp = array(
				'veiculo'	 => $_nVeiculoUp,
				'marca' 	=> $_nMarcaUp,
				'ano' 		=> $_nAnoUp,
				'descricao' => $_nDescricaoUp,
				'vendido' 	=> $_nCheckUp,
				'created' 	=> $_createdUp,
				'updated' 	=> date('Y-m-d H:i:s')
			);

		$this->db->update(
			'veiculos', 
			$veiculosUp, 
			array(
				'id' => $_idVeiculoUp
				)
			);

	}

}